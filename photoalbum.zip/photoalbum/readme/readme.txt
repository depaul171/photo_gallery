1. This is a simple django app that enables you to create a photo gallery. You can add and delete photos to      and from the gallery, but first I recommend you you install python and django onto you machine and the        create a virtual environment before you kick off with interacting with the app

2. Create a project called photoalbum with the instruction below in the terminal or cmd window(assuming you      already have django installed on your machine):
  
  -> django-admin startproject photoalbum 

3. Next make sure to make in a virtual environment(procedure is dependant on operating system used), below is    the procedure for linux systems

   -> virtualenv myenv
   -> source myenv/bin/activate

4. After successful virtual environment creation and activation, you can now run the app by executing the        following command in the terminal or command prompt

   -> python manage.py runserver